package com.simplemobiletools.calculator

import android.app.Application
import android.test.ApplicationTestCase

class ApplicationTest : ApplicationTestCase<Application>(Application::class.java)