package com.simplemobiletools.calculator.operation.base

open class BinaryOperation protected constructor(protected var baseValue: Double, protected var secondValue: Double)
