package com.simplemobiletools.calculator.operation.base

open class UnaryOperation protected constructor(protected var value: Double)
